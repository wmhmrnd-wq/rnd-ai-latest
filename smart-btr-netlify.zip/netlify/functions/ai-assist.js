import { getMemory, saveMemory } from "./lib/memory.js";

export async function handler(event) {
 const { prompt, model } = JSON.parse(event.body || "{}");
 const selectedModel = model || "openai/gpt-4o-mini";
 const userId="default";

 const memory=await getMemory(userId);

 const response=await fetch("https://openrouter.ai/api/v1/chat/completions",{
  method:"POST",
  headers:{
   "Authorization":`Bearer ${process.env.OPENROUTER_API_KEY}`,
   "Content-Type":"application/json"
  },
  body:JSON.stringify({
   model:selectedModel,
   stream:true,
   messages:[...memory,{role:"user",content:prompt}]
  })
 });

 const reader=response.body.getReader();
 const decoder=new TextDecoder();

 const stream=new ReadableStream({
  async start(controller){
   let full="";
   while(true){
    const {done,value}=await reader.read();
    if(done)break;
    const chunk=decoder.decode(value);
    full+=chunk;
    controller.enqueue(value);
   }
   await saveMemory(userId,{role:"user",content:prompt});
   await saveMemory(userId,{role:"assistant",content:full});
   controller.close();
  }
 });

 return new Response(stream,{headers:{"Content-Type":"text/plain"}});
}
